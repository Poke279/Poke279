
# SMSHub Auto Order

SMSHub Auto Order OTP Gmail ID / Spotify CL 

## Fitur

- Nama & API Key Mudah Diubah
- Custom Country
- Custom Services
- Custom Provider



## Penggunaan

Terminal (Android & Windows)

```bash
  pkg update && upgrade
```
```bash
  pkg install git
```
```bash
  pkg install python
```
```bash
  pkg install pip
```
```bash
  git clone https://github.com/MunksCode/smshub
```
```bash
  cd smshub
```
```bash
  pip install -r requirements.txt
```
```bash
  python munks.py
```
## Authors & License

- [@MuhRifq](https://www.t.me/muhrifq)
- [@munkstore](https://www.t.me/munkstore)

